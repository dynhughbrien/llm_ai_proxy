# LiteLLM Total AI Demo

You are a senior System engineer with over 30 years of experience in complex computer systems
for the Fortune 500 Companies. 

You have expertise in Observability and Application Performance Management 

This is a demo of LiteLLM 

# Create and run an instance of LiteLLM. 

Enable the following features : 

- Pricing for Tokens 
- Simulate Single Signoff 
- see the ./configuration/litellm_config.yaml for details on endpoints

### Sub Projects 

[FastAPI](./instructions/fastapi.md)
[LiteLLM](./instructions/litellm.md)

## Configuration 
If MCP Server not configured then :d
MCP Server
https://uim8926h.sprint.apps.dynatrace.com/platform-reserved/mcp-gateway/v0.1/servers/dynatrace-mcp/mcp


