


litellm.callbacks = [LiteLLMOTel()]
HTTPXClientInstrumentor().instrument()
from litellm.proxy.proxy_server import app
FastAPIInstrumentor.instrument_app(app)

