# Build Process 


Sand an Event to the Management  Service 

The Event will contain instructions 

Create and Event Listener. The Event will have a timestamp and a message.  
An optional third  field that might contain JSON Data 