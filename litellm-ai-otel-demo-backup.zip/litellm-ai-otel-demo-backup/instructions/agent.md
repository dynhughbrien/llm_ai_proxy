# Create an AI Based Agent.

Agent will check the FastAPI Service 

Future Option: Agent will interact with AI Through LiteLLM Gateway