# Open Telemetry Configuration

```
# Must run BEFORE litellm imports the proxy app
TRACELOOP_BASE_URL = os.environ["TRACELOOP_BASE_URL"]

Traceloop.init(
    app_name="litellm-gateway",
    api_endpoint=TRACELOOP_BASE_URL,
    api_key="KEY",
    disable_batch=True,
    should_enrich_metrics=True
)
```